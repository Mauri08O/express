const data = [
    {
        fullName: "Jose Gonzalez",
        email: "jg@gmail.com",
        password: ""
    }
];


module.exports = { data }
